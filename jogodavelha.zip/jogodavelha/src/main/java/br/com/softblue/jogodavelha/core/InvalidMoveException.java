package br.com.softblue.jogodavelha.core;

@SuppressWarnings("serial")
public class InvalidMoveException extends Exception {

		public InvalidMoveException(String message) {
		super(message);
		
	}
}
