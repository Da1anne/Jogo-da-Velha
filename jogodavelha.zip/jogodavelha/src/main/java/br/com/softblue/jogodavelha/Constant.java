package br.com.softblue.jogodavelha;

public class Constant {
	
	public static final int BOARD_SIZE = 3;
	
	public static final char[] SYMBOL_PLAYERS = { 'X', 'O'};
	
	
}
