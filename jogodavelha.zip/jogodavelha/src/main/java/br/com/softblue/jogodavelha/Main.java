package br.com.softblue.jogodavelha;

import java.io.IOException;

import br.com.softblue.jogodavelha.core.Game;

public class Main {

	public static void main(String[] args) throws IOException {
		Game g = new Game();
		g.play();
	}

}
