package br.com.softblue.jogodavelha.core;

public class Move {
	
	private int i;
	private int j;
	
	public Move(String moveStr) throws InvalidMoveException {
		try {
		String[] tokens = moveStr.split(",");
		//split � um m�todo, pode ser usado com String pq String � um objeto
		
		this.i = Integer.parseInt(tokens[0]);
		this.j = Integer.parseInt(tokens[1]);
			
		} catch (Exception e) {
			throw new InvalidMoveException("Jogada Inv�lida!");
		}
	}
	
	public int getI() {
		return i;
	}
	

	public int getJ() {
		return j;
	}

}
